# Home - PH eReferral Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://jgsuess.github.io/ph-ereferral/ImplementationGuide/example.fhir.ph.ereferral | *Version*:0.2.0 |
| Draft as of 2026-02-24 | *Computable Name*:PHeReferralImplementationGuide |

### Introduction

PH eReferral is provided in its initial DRAFT form to support the use of HL7® FHIR®© in the Philippines context. It sets the minimum expectations on FHIR resources to support conformance and implementation in systems. This FHIR IG is for testing purposes only and not suitable for production systems.

**⚠ Experimental Fork**

This is a
**fork for experimental and display purposes only**. It is not the authoritative source of the PH eReferral IG. This fork demonstrates three techniques that may be adopted upstream:
* **Example-driven development** — the IG is built around concrete FHIR resource examples derived from a real-world ANC scenario (patient Charity, clerk Abraham, nurse Jane), with every data-dictionary element traced to a working example instance.
* **Automated versioning** — the `main` branch always carries a `-draft` version (e.g. `0.2.0-draft`); release versions are derived from Git tags (`v0.1.0` → IG version `0.1.0`) so the source of truth is never ambiguous.
* **Automated release** — two GitHub Actions workflows publish the IG automatically: a CI lane deploys every push to `main` as a [development preview](dev/), while tagging a release publishes an immutable version to its own URL with history tracking.


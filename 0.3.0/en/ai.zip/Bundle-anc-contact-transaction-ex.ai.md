# anc-contact-transaction-ex - PH eReferral Implementation Guide v0.3.0

## Example Bundle: anc-contact-transaction-ex



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "anc-contact-transaction-ex",
  "type" : "transaction",
  "timestamp" : "2026-02-24T10:00:00+08:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "practitioner-jane-ex",
      "meta" : {
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-1",
          "display" : "REF-1"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_practitioner-jane-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner practitioner-jane-ex</b></p><a name=\"practitioner-jane-ex\"> </a><a name=\"hcpractitioner-jane-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>name</b>: Jane Dela Cruz </p></div>"
      },
      "name" : [{
        "family" : "Dela Cruz",
        "given" : ["Jane"]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Practitioner"
    }
  },
  {
    "fullUrl" : "urn:uuid:5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "practitionerrole-jane-ex",
      "meta" : {
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-1",
          "display" : "REF-1"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_practitionerrole-jane-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole practitionerrole-jane-ex</b></p><a name=\"practitionerrole-jane-ex\"> </a><a name=\"hcpractitionerrole-jane-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>practitioner</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></p><p><b>organization</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-7c9e6679-7425-40de-944b-e07fc1f90ae7\">Organization Barangay Malusog Health Centre</a></p><p><b>code</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/practitioner-role nurse}\">Nurse</span></p></div>"
      },
      "practitioner" : {
        "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
      },
      "organization" : {
        "reference" : "urn:uuid:7c9e6679-7425-40de-944b-e07fc1f90ae7"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/practitioner-role",
          "code" : "nurse",
          "display" : "Nurse"
        }],
        "text" : "Nurse"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "PractitionerRole"
    }
  },
  {
    "fullUrl" : "urn:uuid:1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "organization-receiving-facility-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-organization"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-9",
          "display" : "REF-9"
        },
        {
          "system" : "https://example.com/peref-dd",
          "code" : "REF-10",
          "display" : "REF-10"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_organization-receiving-facility-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization organization-receiving-facility-ex</b></p><a name=\"organization-receiving-facility-ex\"> </a><a name=\"hcorganization-receiving-facility-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-organization</code></p><p style=\"margin-bottom: 0px\">Tags: , </p></div><p><b>identifier</b>: Facility ID/DOH000-OO-0-0000456 (use: official, )</p><p><b>name</b>: Metro Imaging Centre</p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "FI"
          }]
        },
        "system" : "http://doh.gov.ph/fhir/Identifier/doh-nhfr-code",
        "value" : "DOH000-OO-0-0000456"
      }],
      "name" : "Metro Imaging Centre"
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "fullUrl" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "encounter-anc-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-encounter"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-43",
          "display" : "REF-43"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_encounter-anc-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter encounter-anc-ex</b></p><a name=\"encounter-anc-ex\"> </a><a name=\"hcencounter-anc-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-encounter</code></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 424619006}\">First antenatal care contact</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><h3>Participants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Individual</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d\">PractitionerRole Nurse</a></td></tr></table><p><b>period</b>: 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800</p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 77386006}\">Pregnant</span></p><p><b>serviceProvider</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-7c9e6679-7425-40de-944b-e07fc1f90ae7\">Organization Barangay Malusog Health Centre</a></p></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB",
        "display" : "ambulatory"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424619006",
          "display" : "Prenatal visit"
        }],
        "text" : "First antenatal care contact"
      }],
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "participant" : [{
        "individual" : {
          "reference" : "urn:uuid:5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d"
        }
      }],
      "period" : {
        "start" : "2026-02-24T08:30:00+08:00",
        "end" : "2026-02-24T10:00:00+08:00"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "77386006",
          "display" : "Pregnant"
        }]
      }],
      "serviceProvider" : {
        "reference" : "urn:uuid:7c9e6679-7425-40de-944b-e07fc1f90ae7"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "fullUrl" : "urn:uuid:c3d4e5f6-a7b8-9012-cdef-123456789012",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "condition-pregnancy-ex",
      "meta" : {
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-40",
          "display" : "REF-40"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_condition-pregnancy-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition condition-pregnancy-ex</b></p><a name=\"condition-pregnancy-ex\"> </a><a name=\"hccondition-pregnancy-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status provisional}\">Provisional</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 77386006}\">Pregnant</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>onset</b>: 2026-01-01</p><p><b>note</b>: </p><blockquote><div><p>LMP approximately around the New Year holiday; gestational age estimated 12–15 weeks.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "provisional",
          "display" : "Provisional"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "77386006",
          "display" : "Pregnant"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "onsetDateTime" : "2026-01-01",
      "note" : [{
        "text" : "LMP approximately around the New Year holiday; gestational age estimated 12–15 weeks."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Condition"
    }
  },
  {
    "fullUrl" : "urn:uuid:d4e5f6a7-b8c9-0123-defa-234567890123",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-chief-complaint-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-30",
          "display" : "REF-30"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-chief-complaint-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-chief-complaint-ex</b></p><a name=\"observation-chief-complaint-ex\"> </a><a name=\"hcobservation-chief-complaint-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation</code></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category exam}\">Exam</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 10154-3}\">Chief complaint Narrative - Reported</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24</p><p><b>value</b>: Missed menstrual cycle and nausea</p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10154-3",
          "display" : "Chief complaint Narrative - Reported"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24",
      "valueString" : "Missed menstrual cycle and nausea"
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:e5f6a7b8-c9d0-1234-efab-345678901234",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-blood-pressure-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation",
        "http://hl7.org/fhir/StructureDefinition/vitalsigns",
        "http://hl7.org/fhir/StructureDefinition/bp"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-32",
          "display" : "REF-32"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-blood-pressure-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-blood-pressure-ex</b></p><a name=\"observation-blood-pressure-ex\"> </a><a name=\"hcobservation-blood-pressure-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation</code>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a>, <a href=\"http://hl7.org/fhir/R4/bp.html\">Observation Blood Pressure Profile</a></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85354-9}\">Blood pressure systolic &amp; diastolic</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24 09:00:00+0800</p><p><b>performer</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8480-6}\">Systolic blood pressure</span></p><p><b>value</b>: 110 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8462-4}\">Diastolic blood pressure</span></p><p><b>value</b>: 70 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85354-9",
          "display" : "Blood pressure panel with all children optional"
        }],
        "text" : "Blood pressure systolic & diastolic"
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24T09:00:00+08:00",
      "performer" : [{
        "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8480-6",
            "display" : "Systolic blood pressure"
          }]
        },
        "valueQuantity" : {
          "value" : 110,
          "unit" : "mmHg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8462-4",
            "display" : "Diastolic blood pressure"
          }]
        },
        "valueQuantity" : {
          "value" : 70,
          "unit" : "mmHg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:f6a7b8c9-d0e1-2345-fabc-456789012345",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-heart-rate-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation",
        "http://hl7.org/fhir/StructureDefinition/vitalsigns"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-33",
          "display" : "REF-33"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-heart-rate-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-heart-rate-ex</b></p><a name=\"observation-heart-rate-ex\"> </a><a name=\"hcobservation-heart-rate-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation</code>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8867-4}\">Heart rate</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24 09:00:00+0800</p><p><b>performer</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></p><p><b>value</b>: 78 beats/minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8867-4",
          "display" : "Heart rate"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24T09:00:00+08:00",
      "performer" : [{
        "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
      }],
      "valueQuantity" : {
        "value" : 78,
        "unit" : "beats/minute",
        "system" : "http://unitsofmeasure.org",
        "code" : "/min"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:a7b8c9d0-e1f2-3456-abcd-567890123456",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-respiratory-rate-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation",
        "http://hl7.org/fhir/StructureDefinition/vitalsigns"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-34",
          "display" : "REF-34"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-respiratory-rate-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-respiratory-rate-ex</b></p><a name=\"observation-respiratory-rate-ex\"> </a><a name=\"hcobservation-respiratory-rate-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation</code>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 9279-1}\">Respiratory rate</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24 09:00:00+0800</p><p><b>performer</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></p><p><b>value</b>: 18 breaths/minute<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "9279-1",
          "display" : "Respiratory rate"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24T09:00:00+08:00",
      "performer" : [{
        "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
      }],
      "valueQuantity" : {
        "value" : 18,
        "unit" : "breaths/minute",
        "system" : "http://unitsofmeasure.org",
        "code" : "/min"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:b8c9d0e1-f2a3-4567-bcde-678901234567",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-oxygen-saturation-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation",
        "http://hl7.org/fhir/StructureDefinition/vitalsigns"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-35",
          "display" : "REF-35"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-oxygen-saturation-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-oxygen-saturation-ex</b></p><a name=\"observation-oxygen-saturation-ex\"> </a><a name=\"hcobservation-oxygen-saturation-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation</code>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 2708-6}, {http://loinc.org 59408-5}\">Oxygen saturation in Arterial blood</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24 09:00:00+0800</p><p><b>performer</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></p><p><b>value</b>: 98 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "2708-6",
          "display" : "Oxygen saturation in Arterial blood"
        },
        {
          "system" : "http://loinc.org",
          "code" : "59408-5",
          "display" : "Oxygen saturation in Arterial blood by Pulse oximetry"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24T09:00:00+08:00",
      "performer" : [{
        "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
      }],
      "valueQuantity" : {
        "value" : 98,
        "unit" : "%",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:c9d0e1f2-a3b4-5678-cdef-789012345678",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-temperature-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation",
        "http://hl7.org/fhir/StructureDefinition/vitalsigns"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-36",
          "display" : "REF-36"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-temperature-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-temperature-ex</b></p><a name=\"observation-temperature-ex\"> </a><a name=\"hcobservation-temperature-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation</code>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8310-5}\">Body temperature</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24 09:00:00+0800</p><p><b>performer</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></p><p><b>value</b>: 36.8 °C<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeCel = 'Cel')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8310-5",
          "display" : "Body temperature"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24T09:00:00+08:00",
      "performer" : [{
        "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
      }],
      "valueQuantity" : {
        "value" : 36.8,
        "unit" : "°C",
        "system" : "http://unitsofmeasure.org",
        "code" : "Cel"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:d0e1f2a3-b4c5-6789-defa-890123456789",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-weight-ex",
      "meta" : {
        "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation",
        "http://hl7.org/fhir/StructureDefinition/vitalsigns"],
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-37",
          "display" : "REF-37"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-weight-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-weight-ex</b></p><a name=\"observation-weight-ex\"> </a><a name=\"hcobservation-weight-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <code>http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-observation</code>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a></p><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 29463-7}\">Body weight</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24 09:00:00+0800</p><p><b>performer</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></p><p><b>value</b>: 55 kg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codekg = 'kg')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29463-7",
          "display" : "Body weight"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24T09:00:00+08:00",
      "performer" : [{
        "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
      }],
      "valueQuantity" : {
        "value" : 55,
        "unit" : "kg",
        "system" : "http://unitsofmeasure.org",
        "code" : "kg"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:e1f2a3b4-c5d6-7890-efab-901234567890",
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "medicationadministration-ifa-ex",
      "meta" : {
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-38",
          "display" : "REF-38"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationAdministration_medicationadministration-ifa-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationAdministration medicationadministration-ifa-ex</b></p><a name=\"medicationadministration-ifa-ex\"> </a><a name=\"hcmedicationadministration-ifa-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Completed</p><p><b>medication</b>: <span title=\"Codes:{http://snomed.info/sct 776023009}\">Iron and Folic Acid (IFA) tablets</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>context</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>effective</b>: 2026-02-24</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c\">Practitioner Jane Dela Cruz </a></td></tr></table><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>Route</b></td><td><b>Dose</b></td></tr><tr><td style=\"display: none\">*</td><td>1 tablet daily</td><td><span title=\"Codes:{http://snomed.info/sct 26643006}\">Oral route</span></td><td>1 tablet<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{tablet} = '{tablet}')</span></td></tr></table></div>"
      },
      "status" : "completed",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "776023009",
          "display" : "Folic acid and iron only product"
        }],
        "text" : "Iron and Folic Acid (IFA) tablets"
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "context" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "effectiveDateTime" : "2026-02-24",
      "performer" : [{
        "actor" : {
          "reference" : "urn:uuid:4e8f6b0c-5a7d-6c3e-1b0f-9d8a7f6e5d4c"
        }
      }],
      "dosage" : {
        "text" : "1 tablet daily",
        "route" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "26643006",
            "display" : "Oral route"
          }]
        },
        "dose" : {
          "value" : 1,
          "unit" : "tablet",
          "system" : "http://unitsofmeasure.org",
          "code" : "{tablet}"
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationAdministration"
    }
  },
  {
    "fullUrl" : "urn:uuid:f2a3b4c5-d6e7-8901-fabc-012345678901",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "servicerequest-ultrasound-ex",
      "meta" : {
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-12",
          "display" : "REF-12"
        },
        {
          "system" : "https://example.com/peref-dd",
          "code" : "REF-13",
          "display" : "REF-13"
        },
        {
          "system" : "https://example.com/peref-dd",
          "code" : "REF-15",
          "display" : "REF-15"
        },
        {
          "system" : "https://example.com/peref-dd",
          "code" : "REF-31",
          "display" : "REF-31"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_servicerequest-ultrasound-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest servicerequest-ultrasound-ex</b></p><a name=\"servicerequest-ultrasound-ex\"> </a><a name=\"hcservicerequest-ultrasound-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Tags: , , , </p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 103693007}\">Diagnostics</span></p><p><b>priority</b>: Routine</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 268445003}\">Obstetric ultrasound to estimate gestational age</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>authoredOn</b>: 2026-02-24</p><p><b>requester</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d\">PractitionerRole Nurse</a></p><p><b>performer</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed\">Organization Metro Imaging Centre</a></p><p><b>reasonReference</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-c3d4e5f6-a7b8-9012-cdef-123456789012\">Condition Pregnant</a></p><p><b>note</b>: </p><blockquote><div><p>First ANC contact. LMP approximately New Year 2026; gestational age estimated 12–15 weeks. Ultrasound needed before 24 weeks to confirm dates and due date.</p>\n</div></blockquote></div>"
      },
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "103693007",
          "display" : "Diagnostic procedure"
        }],
        "text" : "Diagnostics"
      }],
      "priority" : "routine",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "268445003",
          "display" : "Ultrasound scan - obstetric"
        }],
        "text" : "Obstetric ultrasound to estimate gestational age"
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "authoredOn" : "2026-02-24",
      "requester" : {
        "reference" : "urn:uuid:5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d"
      },
      "performer" : [{
        "reference" : "urn:uuid:1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed"
      }],
      "reasonReference" : [{
        "reference" : "urn:uuid:c3d4e5f6-a7b8-9012-cdef-123456789012"
      }],
      "note" : [{
        "text" : "First ANC contact. LMP approximately New Year 2026; gestational age estimated 12–15 weeks. Ultrasound needed before 24 weeks to confirm dates and due date."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ServiceRequest"
    }
  },
  {
    "fullUrl" : "urn:uuid:a3b4c5d6-e7f8-9012-abcd-123456789012",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "servicerequest-lab-orders-ex",
      "meta" : {
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-39",
          "display" : "REF-39"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_servicerequest-lab-orders-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest servicerequest-lab-orders-ex</b></p><a name=\"servicerequest-lab-orders-ex\"> </a><a name=\"hcservicerequest-lab-orders-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Tag: </p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 108252007}\">Laboratory</span></p><p><b>priority</b>: Routine</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 15220000}\">Diabetes screen, Hepatitis B surface antigen, HIV test</span></p><p><b>subject</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>authoredOn</b>: 2026-02-24</p><p><b>requester</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d\">PractitionerRole Nurse</a></p><p><b>reasonReference</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-c3d4e5f6-a7b8-9012-cdef-123456789012\">Condition Pregnant</a></p><p><b>note</b>: </p><blockquote><div><p>Ordered during first ANC contact: diabetes screening, hepatitis B, HIV.</p>\n</div></blockquote></div>"
      },
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "108252007",
          "display" : "Laboratory procedure"
        }],
        "text" : "Laboratory"
      }],
      "priority" : "routine",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "15220000",
          "display" : "Laboratory test"
        }],
        "text" : "Diabetes screen, Hepatitis B surface antigen, HIV test"
      },
      "subject" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "authoredOn" : "2026-02-24",
      "requester" : {
        "reference" : "urn:uuid:5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d"
      },
      "reasonReference" : [{
        "reference" : "urn:uuid:c3d4e5f6-a7b8-9012-cdef-123456789012"
      }],
      "note" : [{
        "text" : "Ordered during first ANC contact: diabetes screening, hepatitis B, HIV."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ServiceRequest"
    }
  },
  {
    "fullUrl" : "urn:uuid:b4c5d6e7-f8a9-0123-bcde-234567890123",
    "resource" : {
      "resourceType" : "Task",
      "id" : "task-referral-ex",
      "meta" : {
        "tag" : [{
          "system" : "https://example.com/peref-dd",
          "code" : "REF-16",
          "display" : "REF-16"
        },
        {
          "system" : "https://example.com/peref-dd",
          "code" : "REF-42",
          "display" : "REF-42"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_task-referral-ex\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Task task-referral-ex</b></p><a name=\"task-referral-ex\"> </a><a name=\"hctask-referral-ex\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Tags: , </p></div><p><b>status</b>: Requested</p><p><b>businessStatus</b>: <span title=\"Codes:{https://example.com/peref/CodeSystem/referral-disposition requested}\">Requested</span></p><p><b>intent</b>: order</p><p><b>focus</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-f2a3b4c5-d6e7-8901-fabc-012345678901\">ServiceRequest Ultrasound scan - obstetric</a></p><p><b>for</b>: <a href=\"Bundle-registration-transaction-ex.html#urn-uuid-f47ac10b-58cc-4372-a567-0e02b2c3d479\">Charity Santos (official) Female, DoB: 2001-08-15 ( http://doh.gov.ph/fhir/ph-core/NamingSystem/philsys-id-ns#1234-5678901-2)</a></p><p><b>encounter</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-b2c3d4e5-f6a7-8901-bcde-f12345678901\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Prenatal visit; period = 2026-02-24 08:30:00+0800 --&gt; 2026-02-24 10:00:00+0800; reasonCode = Pregnant</a></p><p><b>authoredOn</b>: 2026-02-24</p><p><b>requester</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d\">PractitionerRole Nurse</a></p><p><b>owner</b>: <a href=\"Bundle-anc-contact-transaction-ex.html#urn-uuid-1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed\">Organization Metro Imaging Centre</a></p></div>"
      },
      "status" : "requested",
      "businessStatus" : {
        "coding" : [{
          "system" : "https://example.com/peref/CodeSystem/referral-disposition",
          "code" : "requested",
          "display" : "Requested"
        }]
      },
      "intent" : "order",
      "focus" : {
        "reference" : "urn:uuid:f2a3b4c5-d6e7-8901-fabc-012345678901"
      },
      "for" : {
        "reference" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479"
      },
      "encounter" : {
        "reference" : "urn:uuid:b2c3d4e5-f6a7-8901-bcde-f12345678901"
      },
      "authoredOn" : "2026-02-24",
      "requester" : {
        "reference" : "urn:uuid:5f9a7c1d-6b8e-7d4f-2c1a-0e9b8a7f6e5d"
      },
      "owner" : {
        "reference" : "urn:uuid:1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Task"
    }
  }]
}

```
